package UI;

import java.util.Scanner;

import bean.Employee;
import Service.ServiceInsurance;

public class ExecutorMain {

	public static void main(String[] args) {
		ServiceInsurance service=new ServiceInsurance();
		Scanner scan=new Scanner(System.in);
		
		
		
		
		
		String choice;
		for(;;){
		do{
			System.out.println("please enter your choice");
			System.out.println("1.   register user");
			System.out.println("2.   your insurance sceme based on your salary or designation");
			System.out.println("3.   display employee details");
			
			choice=scan.next();
			boolean isValid = service.validateChoice(choice);
			if (isValid)
				break;
			}while(service.validateChoice(choice)!=true);
		
		
		switch (choice) {
		case "1":
			System.out.println("In the Register employee info department");
			
			String name;
			do{
				System.out.println("Enter name");
				
				
				name=scan.next();
				boolean isValid =service.validateUserName(name);
				if (isValid)
					break;
				}while(service.validateUserName(name)!=true);
			
		
			String salary;
			do{
				System.out.println("Enter salary");
				
				
				salary=scan.next();
				boolean isValid =service.validateSalary(salary);
				if (isValid)
				break;
				}while(service.validateUserName(salary)!=true);
			
			int sal=Integer.parseInt(salary);
			Employee emp=new Employee();
			emp.setSalary(sal);
			emp.setName(name);
			service.storeIntoList(emp);
			
			break;
		case "2":
        	String id;
        	
			do{
				System.out.println("Enter salary");
				
				
				id=scan.next();
				boolean isValid =service.validateId(id);
				if (isValid)
				break;
				}while(service.validateId(id)!=true);
			
			service.showDetails(Integer.parseInt(id));
			
        	
			break;	
		case "3":
			System.exit(0);
			break;
		}

	}}

}
