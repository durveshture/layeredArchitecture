package Dao;

import java.util.ArrayList;
import java.util.List;

import bean.Employee;

public class DaoInsurance implements DaoInsuranceinterface {
	List<Employee> employee=new ArrayList<Employee>();
	private static int id=1001;
	

	@Override
	public void storeToList(Employee emp) {
		emp.setId(id);
		int sal=emp.getSalary();
		
		if ( sal >=40000  ) {
			emp.setDesignation("Manager");
			emp.setInsuranceScheme("Scheme A");
		} else if (sal<40000 && sal>=20000) {
			emp.setDesignation("Programmer");
			emp.setInsuranceScheme("Sceme B");
		} else if (sal<20000 && sal>=5000) {
			emp.setDesignation("System Associate");
			emp.setInsuranceScheme("Sceme C");
		} else {
			emp.setDesignation("Clerk");
			emp.setInsuranceScheme("No Scheme");
		}
		
		employee.add(emp);
		System.out.println("Information successfully saved ");
		id++;
		
	}

	@Override
	public Employee showDetails(int id) {
		// TODO Auto-generated method stub
		if (employee!=null) {
			for (Employee emp : employee) {
				if (emp.equals(new Employee(emp.getId(),null,0,null,null))) {
					return emp;
				}
				
			}
			
		}else System.out.println("record not dound");
		return null;
	}
	
	
	

		
	

}
