package Dao;

import bean.Employee;


public interface DaoInsuranceinterface {
	
	void storeToList(Employee emp);
	Employee showDetails(int id);
	
	
	
	

}
