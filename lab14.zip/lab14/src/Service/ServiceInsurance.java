package Service;

import java.util.Scanner;

import Dao.DaoInsurance;
import bean.Employee;


public class ServiceInsurance implements ServiceInterfaceOInsurance {
	Scanner scan = new Scanner(System.in);
	Employee emp=new Employee();
	DaoInsurance dao=new DaoInsurance();


	@Override
	public boolean validateChoice(String userChoice) {
		if (userChoice.matches(userChoicePattern)) 
			return true;
		else
		 return false;
	}

	@Override
	public void registerEmployee() {
		
		
//		emp.setId(id);
//		id++;
		
		
		
	}
	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern)) 
			return true;
		else
		 return false;
	}

	@Override
	public boolean validateSalary(String Salary) {
		if (Salary.matches(userSalaryPattern)) 
			return true;
		else
		 return false;
	}

	@Override
	public void storeIntoList(Employee emp) {
		dao.storeToList(emp);
		
	}

	

	@Override
	public Employee showDetails(int id) {
		return dao.showDetails(id);
	}

	@Override
	public boolean validateId(String Id) {
		
			if (Id.matches(userID)) 
				return true;
			else
			 return false;
	}

	
	

}
