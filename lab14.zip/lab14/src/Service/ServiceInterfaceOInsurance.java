package Service;

import bean.Employee;



public interface ServiceInterfaceOInsurance {
	
	String userNamePattern="[A-Z][a-z]{1,9}";
	String userSalaryPattern="[0-9]{2,8}";
	//String userAddressPattern="^[a-zA-Z0-9_]+( [a-zA-Z0-9_]+)*$";
	String userChoicePattern="[1-3]{1}";
	String userID = "[0-9]{4}";
	//String userMailPatter="^(.+)@(.+)$";
	boolean validateUserName(String userName);
	boolean validateSalary(String Salary);
	//boolean validateUserAddress(String userAddress);
	boolean validateChoice(String userChoice);
	boolean validateId(String Id);
	//boolean validateEmail(String useraMail);
	///=void storeIntoMap(Person person);
	public void registerEmployee();
	public void storeIntoList(Employee emp);
	

	Employee showDetails(int id);
	

}
